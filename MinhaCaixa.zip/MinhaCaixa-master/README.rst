Minha Caixa 
===========

.. image:: images/MinhaCaixaSmall.png
   
Projeto destinado ao ensino aprendizagem de banco de dados

Links de Apoio

- `Mentoring para prova MTA - Fundamento de Banco de Dados <http://pt.slideshare.net/rdornel/mentoring-para-prova-mta-fundamento-de-banco-de-dados>`_

- `Microsoft Virtual Labs - Máuinas Virtuais Gratuitas para aprendizado <https://technet.microsoft.com/en-us/virtuallabs?id=IMUmyf7VAbE>`_


